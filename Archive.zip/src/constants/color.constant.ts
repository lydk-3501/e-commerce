export const SLIDER_TRACK_BG = '#ccc';
export const SLIDER_TRACK_HIGHLIGHT = '#e2a400';

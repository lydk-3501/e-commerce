export const sortByOptions = [
    'Sort by feature',
    'Price ascending',
    'Price descending',
];

export const hitsOptions = [16, 32, 64];

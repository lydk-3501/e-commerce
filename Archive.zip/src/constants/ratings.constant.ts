export const ratingNumbers = [4, 3, 2, 1];
